/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.iotdb.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class JDBCExample {

  public static void main(String[] args){
    JDBCExample jdbcExample = new JDBCExample();
    jdbcExample.insert();
  }

  public void insert() {
    try {
      Class.forName("org.apache.iotdb.jdbc.IoTDBDriver");
      Connection connection =
          DriverManager.getConnection("jdbc:iotdb://127.0.0.1:6667/", "root", "root");
      Statement statement = connection.createStatement();
      Date d = new Date();
      for (int i = 2000; i <= 2001; i++) {
        Calendar c = Calendar.getInstance();
        for (int t = 1; t <= 10800; t++) {
          String path = "root.s99.ss" + i;
          c.add(Calendar.SECOND, +2);
          Random r = new Random();
          statement.execute(
              "insert into "
                  + path
                  + "(timestamp, s1) values("
                  + c.getTimeInMillis()
                  + ","
                  + (-2 + 6 * r.nextFloat())
                  + ")");
        }
      }
      System.out.println("insert data finish...");
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    } catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }
}
