
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.iotdb.session.Session;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.influxdb.dto.QueryResult.Result;
import org.influxdb.dto.QueryResult.Series;

public class InsertTestData {
	public static void main(String[] args) {
		 InsertTestData t=new InsertTestData();
		 t.insert();
	}
	public void insert() {
		  try {
		    	Class.forName("org.apache.iotdb.jdbc.IoTDBDriver");
		        Connection connection =
		            DriverManager.getConnection("jdbc:iotdb://127.0.0.1:6667/", "root", "root");
		        Statement statement = connection.createStatement();
				Date d=new Date();
				Calendar c=	Calendar.getInstance();
		        	for(int t=1;t<=1080;t++){
		        		String path="root.ssg"+2;
								c.add(Calendar.SECOND,+2);
								Random r=new Random();
								statement.execute("insert into "+path+"(timestamp, s1) values("+ c.getTimeInMillis()+ "," + (-2+6*r.nextFloat())+")");	
		        	}
				Date d1=new Date();
		      } catch (SQLException throwables) {
		        throwables.printStackTrace();
		      } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
}
